<?php
$hostName = "localhost";
$dbUser = "root";
$dbPassword = "";
$dbName = "portal";

// Create connection
$conn = mysqli_connect($hostName, $dbUser, $dbPassword, $dbName);

// Check connection
if (mysqli_connect_errno()) {
    die("Connection failed: " . mysqli_connect_error());
}


?>
